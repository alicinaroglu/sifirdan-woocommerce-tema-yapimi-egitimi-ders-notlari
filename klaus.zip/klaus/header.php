<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width">
<?php $favicon = get_field('favicon', 'option'); ?>
<link rel="shortcut icon" href="<?php echo $favicon['url']; ?>" type="image/x-icon" />

<title><?php wp_title( '|', true, 'right' ); ?></title>
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php include('style.php'); ?>	
<?php wp_head(); ?>
</head>
<body <?php body_class('drawer drawer--left'); ?>>
<header role="banner" class="sadece-mobil">
<nav class="drawer-nav" role="navigation">
	
<?php wp_nav_menu( array( 'theme_location' => 'ustmenu', 'menu_class' => 'ust-bar-menu', 'menu_id' => 'ust-bar-menu' ) ); ?>	
</nav>
</header>	
	
<div class="container ust-bar" id="sayfabasi">
	<div class="row">
		<div class="col-md-6 ust-bar-sol">
		<?php if(get_field('slogan_alani_gozuksun_mu_','option')): ?>
		<?php the_field('slogan_alani','option');?>
		<?php endif;?>
		</div>
		<div class="col-md-6 ust-bar-sag">
		<?php if(get_field('ust_menu_alani_gozuksun_mu_','option')): ?>	
			
			<?php if ( is_user_logged_in()) : $kullanici = wp_get_current_user(); ?>
			
			<span class="ust-bar-karsilama">Merhaba <a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>"><?php echo $kullanici->display_name;?></a></span>

			<?php else:?>	
			
			<span class="ust-bar-karsilama"><a href="<?php echo get_permalink( get_option('woocommerce_myaccount_page_id') ); ?>">Üye Ol / Giriş Yap</a></span>
			
			<?php endif;?>
			
		<?php wp_nav_menu( array( 'theme_location' => 'ustmenu', 'menu_class' => 'ust-bar-menu', 'menu_id' => 'ust-bar-menu' ) ); ?>	
		<?php endif;?>
		</div>
	</div>
</div>
	
<div class="container ust-orta-bolum">
<div class="row">
	<div class="col-md-3 col-lg-3 logo-alani">
	<?php $site_logosu = get_field('site_logosu','option');?>	
	<a href="<?php echo bloginfo('url');?>"><img src="<?php echo $site_logosu['url'];?>" alt="" class="site-logosu"/></a>
	</div>
	
	<div class="col-md-6 col-lg-7 arama-alani">
		
	<form name="header-arama" method="GET" class="header-arama" action="<?php echo esc_url(home_url('/')); ?>">
    <?php if (class_exists('WooCommerce')) : ?>
		
		<?php 
		  if(isset($_REQUEST['product_cat']) && !empty($_REQUEST['product_cat'])) { 
			  
			  $secili_kategori=$_REQUEST['product_cat'];
		  }
		  else { 
			  
			  $secili_kategori=0; 
		  }
		
	
		
		$args = array(
		
		'show_option_all' => esc_html__('Tüm Kategoriler'),
		'class' => 'cat',
		'hierarchical' => 1,
		'depth' => 1,	
		'value_field' => 'slug',
		'hide_empty' => 0,
		'echo' => 1,
		'selected' => $secili_kategori,
		
		); 
		
		$args['taxonomy'] = 'product_cat';
		$args['name'] = 'product_cat';
		$args['class'] = 'urun_kategorisi hidden-xs';
	
		wp_dropdown_categories($args);
		
		
	   ?>
  		<input type="hidden" value="product" name="post_type">
		
	<?php endif; ?>
	<input type="text" name="s" class="arama-input" required maxlength="128" value="<?php echo get_search_query(); ?>" placeholder="<?php esc_attr_e('Ürün Ara | Ör. iPhone XS Max...', 'woocommerce'); ?>">
	<button type="submit" title="<?php esc_attr_e('Ara', 'woocommerce'); ?>" class="arama-buton"><span><i class="fas fa-search"></i></span></button>

	</form>	
		
	</div>
	
	<div class="col-md-3 col-lg-2 sepet-alani">
	
	<span class="sepet-baslik">SEPETİNİZDE</span>
	<a href="<?php echo wc_get_cart_url(); ?>">
	<span class="sepet-guncel">
	<span class="sepet-urun"><?php echo WC()->cart->cart_contents_count; ?> Ürün Var</span>
	<span class="sepet-fiyat"><?php echo WC()->cart->get_cart_total(); ?></span>
	</span>
	</a>
		
	</div>
	
</div>
</div>	
	
<div class="container menu-alani">
<button type="button" class="drawer-toggle drawer-hamburger">
<span class="sr-only">Menü</span>  
<span class="drawer-hamburger-icon">   
<span style="display: block;    margin-left: 20px;    line-height: 0px;    width: 87px;"></span>
</span>
</button>
<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_class' => 'ana-menu', 'menu_id' => 'ana-menu' ) ); ?>	
</div>