<?php get_header(); ?>

<div class="container-fluid">
	<div class="row">
	<div class="col-md-4 sayfa-ic-sol">
		<?php $solfoto1=get_field('sol_fotograf_1',98);?>
		<img src="<?php echo $solfoto1['url'];?>" class="solfoto1">
		<div class="clearfix"></div>
	</div>
	<div class="col-md-1"></div>	
	<div class="col-md-7 sayfa-ic-sag">
	
		
	<div class="clearfix margin-bottom-40"></div>	
	<h1 class="anasayfa-buyuk-baslik" align="left"><span class="bold renk-gri"><?php the_field('hizmetler_baslik');?></span></h1>	
	<div class="clearfix margin-bottom-20"></div>	
		<?php while ( have_posts() ) : the_post(); ?>
<div class="row margin-bottom-30">
	<h1><?php the_title();?></h1>
	<a href="<?php the_permalink();?>"><?php the_post_thumbnail();?></a>
	<?php the_excerpt();?>
	<a href="<?php the_permalink();?>" class="buton-sepete-ekle" style="width:200px;"><span class="bold">Devamını</span> Oku</a>
	</div>	
		<?php endwhile; ?>
		
	</div>
	
		
	
	
	<div class="clearfix"></div>	
		
		
		
	</div>
</div>

<div class="clearfix"></div>
<?php get_footer(); ?>
