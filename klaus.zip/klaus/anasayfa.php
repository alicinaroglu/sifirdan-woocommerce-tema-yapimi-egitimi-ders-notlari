<?php /*Template Name: Ana Sayfa*/ get_header(); ?>



<div class="container-fluid slider-arkasi">
	<div class="container slider-alani">
    <div class="swiper-container">
    <div class="swiper-wrapper">
		
		  <?php if( have_rows('slider','option') ): while ( have_rows('slider','option') ) : the_row(); ?>
			<?php $slide_gorseli = get_sub_field('slide_gorseli','option');?>
		  	
		 <div class="swiper-slide" style="background-image: url('<?php echo $slide_gorseli['url'];?>')">
		  <span class="slide-baslik"><?php the_sub_field('slide_basligi','option');?></span>
		  <div class="clearfix"></div>
		  <a href="<?php the_sub_field('slide_link','option');?>" class="kirmizi-buton">Detaylı İncele</a>
			</div>
		
		
		  <?php endwhile; endif; ?>
		
    </div>
  
    <div class="swiper-pagination"></div>

    <div class="swiper-button-prev">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 27 44"><path d="M0,22L22,0l2.1,2.1L4.2,22l19.9,19.9L22,44L0,22L0,22L0,22z"></path></svg>
	</div>
    <div class="swiper-button-next">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 27 44"><path d="M27,22L27,22L5,44l-2.1-2.1L22.8,22L2.9,2.1L5,0L27,22L27,22z"></path></svg>
	</div>
  </div>
	</div>
</div>


<div class="container p-0 anasayfa-urunler">
	
	<span class="tab-baslik renkli-baslik"><?php the_field('ana_sayfa_urunler_baslik','option');?></span>	
	
<ul class="nav nav-tabs anasayfa-urunler-tab" role="tablist">
	
<?php if(get_field('one_cikan_urunler_gosterilsin_mi_','option')):?>
<li class="nav-item">
		<a class="nav-link active" id="onecikan-tab" data-toggle="tab" href="#onecikan" role="tab" aria-controls="onecikan"><?php the_field('one_cikan_urunler_baslik','option');?></a>
</li>
<?php endif;?>
	
<?php if(get_field('son_eklenen_urunler_gosterilsin_mi_','option')):?>
<li class="nav-item">
		<a class="nav-link" id="soneklenen-tab" data-toggle="tab" href="#soneklenen" role="tab" aria-controls="soneklenen"><?php the_field('son_eklenen_urunler_baslik','option');?></a>
</li>
<?php endif;?>
	
<?php if(get_field('cok_satan_urunler_gosterilsin_mi_','option')):?>
<li class="nav-item">
		<a class="nav-link" id="coksatan-tab" data-toggle="tab" href="#coksatan" role="tab" aria-controls="coksatan"><?php the_field('cok_satan_urunler_baslik','option');?></a>
</li>
<?php endif;?>	
	
<?php if(get_field('indirimdeki_urunler_gosterilsin_mi_','option')):?>
<li class="nav-item">
		<a class="nav-link" id="indirim-tab" data-toggle="tab" href="#indirim" role="tab" aria-controls="indirim"><?php the_field('indirimdeki_urunler_baslik','option');?></a>
</li>
<?php endif;?>	
	
	
<?php 
$anasayfa_kategori_secimi = get_field('kategori_secimi','option');
if( $anasayfa_kategori_secimi ): ?>
	<?php foreach( $anasayfa_kategori_secimi as $anasayfa_kategori_secim ): ?>
	<li class="nav-item">
		<a class="nav-link " id="<?php echo $anasayfa_kategori_secim->slug; ?>-tab" data-toggle="tab" href="#<?php echo $anasayfa_kategori_secim->slug; ?>" role="tab" aria-controls="<?php echo $anasayfa_kategori_secim->slug; ?>"><?php echo $anasayfa_kategori_secim->name; ?></a>
	</li>
		
	<?php endforeach; ?>
<?php endif; ?>	
</ul>
	
	
<div class="tab-content" id="anasayfa_urunler_icerik">

<?php if(get_field('one_cikan_urunler_gosterilsin_mi_','option')):?>
	
<div class="tab-pane fade show active" id="onecikan" role="tabpanel" aria-labelledby="onecikan-tab">
	
<div class="row">
			
<?php 
$onecikanurunler = get_field('one_cikan_urunler','option');
if( $onecikanurunler ): ?>
<?php foreach( $onecikanurunler as $post): ?>
<?php setup_postdata($post); global $product; ?>

<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	
	<?php woocommerce_template_loop_add_to_cart(); ?>	
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
			

<?php endforeach; ?>
<?php wp_reset_postdata(); ?>
<?php endif; ?>	
<?php wp_reset_query(); ?>				
			
</div>
	
</div>
<?php endif;?>	
	
	
	
<?php if(get_field('son_eklenen_urunler_gosterilsin_mi_','option')):?>
	
<div class="tab-pane fade" id="soneklenen" role="tabpanel" aria-labelledby="soneklenen-tab">
	
<div class="row">
			
<?php
$gosterilecek_urun_sayisi = get_field('gosterilecek_urun_sayisi','option');
	
$args = array(
    'post_type' => 'product',
    'orderby' => 'date',
    'posts_per_page' => $gosterilecek_urun_sayisi,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>

<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
			

<?php endwhile; ?>
<?php wp_reset_query(); ?>					
			
</div>
	
</div>
<?php endif;?>	
	

<?php if(get_field('cok_satan_urunler_gosterilsin_mi_','option')):?>
	
<div class="tab-pane fade" id="coksatan" role="tabpanel" aria-labelledby="coksatan-tab">
	
<div class="row">
			
<?php
	
$args = array(
    'post_type' => 'product',
	'meta_key' => 'total_sales',
    'orderby' => 'meta_value_num',
    'posts_per_page' => $gosterilecek_urun_sayisi,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>

<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
			

<?php endwhile; ?>
<?php wp_reset_query(); ?>					
			
</div>
	
</div>
<?php endif;?>	
	

<?php if(get_field('indirimdeki_urunler_gosterilsin_mi_','option')):?>
	
<div class="tab-pane fade" id="indirim" role="tabpanel" aria-labelledby="indirim-tab">
	
<div class="row">
			
<?php
	
$args = array(
    'post_type' => 'product',
	'meta_query'     => array(
        'relation' => 'OR',
        array( 
            'key'           => '_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        ),
        array( 
            'key'           => '_min_variation_sale_price',
            'value'         => 0,
            'compare'       => '>',
            'type'          => 'numeric'
        )
    ),
    'posts_per_page' => $gosterilecek_urun_sayisi,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>

<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
			

<?php endwhile; ?>
<?php wp_reset_query(); ?>					
			
</div>
	
</div>
<?php endif;?>		
	
	
	
	
	
<div class="tab-pane fade" id="<?php echo $anasayfa_kategori_secimi[0]->slug;?>" role="tabpanel" aria-labelledby="<?php echo $anasayfa_kategori_secimi[0]->slug;?>-tab">	

<div class="row">

<?php
	
$args = array(
    'post_type' => 'product',
    'orderby' => 'date',
    'posts_per_page' => $gosterilecek_urun_sayisi,
	'product_cat' => $anasayfa_kategori_secimi[0]->slug,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>	
	
<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
		
	
<?php endwhile; ?>
<?php wp_reset_query(); ?>	
	
</div>	
</div>	
	
	
	
<div class="tab-pane fade" id="<?php echo $anasayfa_kategori_secimi[1]->slug;?>" role="tabpanel" aria-labelledby="<?php echo $anasayfa_kategori_secimi[1]->slug;?>-tab">	

<div class="row">

<?php
	
$args = array(
    'post_type' => 'product',
    'orderby' => 'date',
    'posts_per_page' => $gosterilecek_urun_sayisi,
	'product_cat' => $anasayfa_kategori_secimi[1]->slug,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>	
	
<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
		
	
<?php endwhile; ?>
<?php wp_reset_query(); ?>	
	
</div>	
</div>
	
	
	
	
<div class="tab-pane fade" id="<?php echo $anasayfa_kategori_secimi[2]->slug;?>" role="tabpanel" aria-labelledby="<?php echo $anasayfa_kategori_secimi[2]->slug;?>-tab">	

<div class="row">

<?php
	
$args = array(
    'post_type' => 'product',
    'orderby' => 'date',
    'posts_per_page' => $gosterilecek_urun_sayisi,
	'product_cat' => $anasayfa_kategori_secimi[2]->slug,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>	
	
<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
		
	
<?php endwhile; ?>
<?php wp_reset_query(); ?>	
	
</div>	
</div>
	
	
	
	
<div class="tab-pane fade" id="<?php echo $anasayfa_kategori_secimi[3]->slug;?>" role="tabpanel" aria-labelledby="<?php echo $anasayfa_kategori_secimi[3]->slug;?>-tab">	

<div class="row">

<?php
	
$args = array(
    'post_type' => 'product',
    'orderby' => 'date',
    'posts_per_page' => $gosterilecek_urun_sayisi,
	'product_cat' => $anasayfa_kategori_secimi[3]->slug,
);
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); ?>	
	
<div class="col-md-4 col-lg-3">
	<div class="urun-kutu">
	<a href="<?php the_permalink();?>">
	<?php if (has_post_thumbnail( $loop->post->ID )):
	echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog',array('class'=>'img-fluid anasayfa-urun-liste-foto')); ?>
	<?php else:?>
	Ürün Görseli Yok	
	<?php endif;?>
	</a>
	<span class="urun-kutu-baslik"><a href="<?php the_permalink();?>"><?php the_title(); ?></a></span>
	<div class="clearfix"></div>
	<div class="urun-kutu-fiyat">
		
	<?php 
	$normal_fiyat = (float) $product->get_regular_price(); 
	$indirimli_fiyat = (float) $product->get_price();

	$indirim_orani = round( 100 - ( $indirimli_fiyat / $normal_fiyat * 100 ), 1 ) . '%';
	if( $product->is_on_sale() ) echo '<span class="urun-liste-indirim-orani">' . $indirim_orani .' <br> indirim </span> '; 
	?>	
	
	<?php echo $product->get_price_html(); ?></div>
	<div class="urun-kutu-sepete-ekle">
	<form class="cart" action="" method="post" enctype='multipart/form-data'>
		<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" class="kirmizi-buton"><?php echo esc_html( $product->single_add_to_cart_text() ); ?></button>
		<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>
	</form>
	</div>	
	<div class="clearfix"></div>
	</div>

</div>			
		
	
<?php endwhile; ?>
<?php wp_reset_query(); ?>	
	
</div>	
</div>
	

	
	
	
</div>
	
	
<?php $site_logosu = get_field('site_logosu','option');?>	
<a href="<?php echo bloginfo('url');?>"><img src="<?php echo $site_logosu['url'];?>" alt="" class="anasayfa-urunler-alt-logo"/></a>
</div>

<?php get_footer(); ?>