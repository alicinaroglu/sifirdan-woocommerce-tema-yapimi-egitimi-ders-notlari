<?php 

function klaus_setup() {

load_theme_textdomain( 'klaus', get_template_directory() . '/languages' );
add_theme_support( 'woocommerce' );
add_theme_support( 'automatic-feed-links' );
add_theme_support( 'html5', array(
'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
) );

add_theme_support( 'wc-product-gallery-zoom' );
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );		
	
register_nav_menu( 'primary', __( 'Ana Menü', 'klaus' ) );
register_nav_menu( 'ustmenu', __( 'Üst Menü', 'klaus' ) );
register_nav_menu( 'footermenu1', __( 'Footer Menü 1', 'klaus' ) );
register_nav_menu( 'footermenu2', __( 'Footer Menü 2', 'klaus' ) );	
register_nav_menu( 'footermenu3', __( 'Footer Menü 3', 'klaus' ) );	
register_nav_menu( 'mobil', __( 'Mobil Menü', 'klaus' ) );		

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 604, 270, true );

add_filter( 'use_default_gallery_style', '__return_false' );

}
add_action( 'after_setup_theme', 'klaus_setup' );



function klaus_cagirilacak_dosyalar() {
	
wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/inc/bootstrap/css/bootstrap.css', array() );
wp_enqueue_style( 'slider', get_template_directory_uri() . '/inc/slider/css/swiper.min.css', array() );
wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.03' );
wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/inc/fontawesome/css/all.min.css', array() );	
wp_enqueue_style( 'drawer1', get_template_directory_uri() . '/inc/drawer-master/dist/css/drawer.css', array() );		
	
	
wp_enqueue_style( 'klaus-style', get_stylesheet_uri(), array() );
wp_enqueue_style( 'responsive', get_template_directory_uri() . '/css/responsive.css', array() );


wp_enqueue_script( 'jquery', get_template_directory_uri().'/inc/jquery/jquery-3.3.1.min.js',array(),'1.0.0',true);	
wp_enqueue_script( 'klaus-script', get_template_directory_uri() . '/inc/bootstrap/js/bootstrap.js', array( 'jquery' ), '2016-19-08', true );
wp_enqueue_script( 'slider2', get_template_directory_uri() . '/inc/slider/js/swiper.min.js', array( 'jquery' ), '2016-19-08', true );
wp_enqueue_script( 'drawer2', get_template_directory_uri() . '/inc/drawer-master/src/js/drawer.js', array( 'jquery' ), '2016-19-08', true );
wp_enqueue_script( 'iscroll', get_template_directory_uri() . '/inc/iscroll/iscroll.min.js', array( 'jquery' ), '2016-19-08', true );	
wp_enqueue_script( 'jscript', get_template_directory_uri() . '/inc/scripts.js', array( 'jquery' ), '2016-19-08', true );	

add_editor_style( array( 'css/editor-style.css', 'genericons/genericons.css' ) );
}

add_action( 'wp_enqueue_scripts', 'klaus_cagirilacak_dosyalar' );



/*Fotoğraf Boyutları*/
function klaus_fotograf_boyutlari()
{
    add_image_size( 'thumb', 567, 437, true); 

}
add_action( 'after_setup_theme', 'klaus_fotograf_boyutlari' );



/*ACF*/
add_filter('acf/settings/path', 'my_acf_settings_path');
function my_acf_settings_path( $path ) {
    $path = get_stylesheet_directory() . '/inc/acf/';
    return $path;
}

add_filter('acf/settings/dir', 'my_acf_settings_dir');
function my_acf_settings_dir( $dir ) {
    $dir = get_stylesheet_directory_uri() . '/inc/acf/';
    return $dir;
    
}

//add_filter('acf/settings/show_admin', '__return_false');

include_once( get_stylesheet_directory() . '/inc/acf/acf.php' );

add_filter('acf/settings/save_json', 'my_acf_json_save_point');
function my_acf_json_save_point( $path ) {
    $path = get_stylesheet_directory() . '/inc/acfsettings/';
    return $path;
    
}

if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'page_title' 	=> 'Site Ayarları',
		'menu_title'	=> 'Site Ayarları',
		'menu_slug' 	=> 'site-ayarlari',
		'capability'	=> 'manage_options',
		'redirect'		=> false
	));
	
	acf_add_options_page(array(
		'page_title' 	=> 'Ana Sayfa Ayarları',
		'menu_title'	=> 'Ana Sayfa Ayarları',
		'menu_slug' 	=> 'anasayfa-ayarlari',
		'parent_slug'	=> 'site-ayarlari',
		'capability'	=> 'manage_options',
		'redirect'		=> false
	));
		
}

/*Admin Bar Kaldırır*/
add_action('after_setup_theme', 'admin_bar_kaldirma');
function admin_bar_kaldirma() {
show_admin_bar(false);
}

/*Editörü Eski Haline Getirir*/
add_filter('use_block_editor_for_post', '__return_false', 10);
add_filter('use_block_editor_for_post_type', '__return_false', 10);


/*Arama Sonuçlarını Direkt Ürüne Yönlendirmez*/
add_filter( 'woocommerce_redirect_single_search_result', '__return_false' );

/*Sepet Güncelleyici*/
add_filter( 'woocommerce_add_to_cart_fragments', 'klaus_sepet' );
function klaus_sepet( $urunler ) {
	ob_start();
	?>
	<span class="sepet-guncel">
	<span class="sepet-urun"><?php echo WC()->cart->cart_contents_count;?> Ürün Var</span>
	<span class="sepet-fiyat"><?php echo WC()->cart->get_cart_total(); ?></span>
	</span>
	<?php
	
	$urunler['.sepet-guncel'] = ob_get_clean();
	return $urunler;
}


function baslik_yapar( $title, $sep ) {
	global $paged, $page;

	if ( is_feed() ) {
		return $title;
	}

	$title .= get_bloginfo( 'name', 'display' );

	$site_description = get_bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) ) {
		$title = "$title $sep $site_description";
	}

	if ( ( $paged >= 2 || $page >= 2 ) && ! is_404() ) {
		$title = "$title $sep " . sprintf( __( 'Sayfa %s', 'twentythirteen' ), max( $paged, $page ) );
	}

	return $title;
}
add_filter( 'wp_title', 'baslik_yapar', 10, 2 );


add_filter('acf/validate_value/name=kategori_secimi', 'anasayfa_kategori_secim_sayisi', 10, 4);
function anasayfa_kategori_secim_sayisi($valid, $value, $field, $input) {

	if(!$valid) {
		return $valid;
	}

	if(sizeof($value) > 4) {
		$valid = 'Maksimum 4 öğe seçebilirsiniz';
	} else {
		$valid = true;
	}

	return $valid;

}


add_filter( 'body_class', 'anasayfaya_class_ekle');
function anasayfaya_class_ekle( $classes ) {
     if ( is_front_page() )
          $classes[] = 'woocommerce';
 
     return $classes; 
}



add_filter( 'woocommerce_breadcrumb_defaults', 'breadcrumb_ozellestirme' );
function breadcrumb_ozellestirme() {
    return array(
            'wrap_before' => '<nav aria-label="breadcrumb"><ol class="breadcrumb">',
            'wrap_after'  => '</ol></nav>',
            'before'      => '<li class="breadcrumb-item">',
            'after'       => '</li>',
            'home'        => _x( 'Ana Sayfa', 'breadcrumb', 'woocommerce' ),
        );
}


function klaus_sidebarlar() {
    register_sidebar(
        array (
            'name' => __( 'Mağaza Sidebarı', 'klaus' ),
            'id' => 'magaza-sidebar',
            'description' => __( 'Mağaza Sidebarı', 'klaus' ),
            'before_widget' => '<div class="beyaz-kutu">',
            'after_widget' => "</div>",
            'before_title' => '<h3 class="tab-baslik renkli-baslik">',
            'after_title' => '</h3><div class="clearfix"></div>',
        )
    );
}
add_action( 'widgets_init', 'klaus_sidebarlar' );


add_filter( 'woocommerce_product_tabs', 'tab_isimlendirme', 98 );
function tab_isimlendirme( $tabs ) {

	$tabs['description']['title'] = __( 'Genel Bakış' );

	return $tabs;

}



add_filter( 'woocommerce_product_tabs', 'tab_yeni_ozellik_tablosu' );
function tab_yeni_ozellik_tablosu( $tabs ) {
	
	$tabs['ozellik_tablosu'] = array(
		'title' 	=> __( 'Ürün Özellikleri', 'woocommerce' ),
		'priority' 	=> 50,
		'callback' 	=> 'tab_yeni_ozellik_tablosu_icerik'
	);

	return $tabs;

}
function tab_yeni_ozellik_tablosu_icerik() { ?>

<table class="table table-sm table-bordered table-hover table-striped">
<tbody>
<?php if( have_rows('urun_ozellik_tablosu') ): while ( have_rows('urun_ozellik_tablosu') ) : the_row(); ?>
<tr>
<th scope="row"><?php the_sub_field('baslik');?></th>
<td><?php the_sub_field('ozellik');?></td>
</tr>
<?php endwhile; endif; ?>
</tbody>
</table>

<?php }

add_filter( 'woocommerce_product_tabs', 'tab_odeme_secenekleri' );
function tab_odeme_secenekleri( $tabs ) {
	
	$tabs['odeme_secenekleri'] = array(
		'title' 	=> __( 'Ödeme Seçenkleri', 'woocommerce' ),
		'priority' 	=> 50,
		'callback' 	=> 'tab_odeme_secenekleri_icerik'
	);

	return $tabs;

}
function tab_odeme_secenekleri_icerik() { ?>

<?php the_field('odeme_secenekleri');?>

<?php }


add_filter( 'woocommerce_product_tabs', 'tab_yeniden_siralama', 98 );
function tab_yeniden_siralama( $tabs ) {

	
	$tabs['description']['priority'] = 5;
	$tabs['ozellik_tablosu']['priority'] = 10;
	$tabs['reviews']['priority'] = 15;
	$tabs['odeme_secenekleri']['priority'] = 20;

	return $tabs;
}


add_filter( 'woocommerce_product_description_heading', '__return_null' );


add_filter( 'woocommerce_product_tabs', 'tab_iptali', 98 );
 
function tab_iptali( $tabs ) {
    unset( $tabs['additional_information'] ); 
    return $tabs;
}

function ucretsiz_ise_gizle( $rates ) {
	$free = array();
	foreach ( $rates as $rate_id => $rate ) {
		if ( 'free_shipping' === $rate->method_id ) {
			$free[ $rate_id ] = $rate;
			break;
		}
	}
	return ! empty( $free ) ? $free : $rates;
}
add_filter( 'woocommerce_package_rates', 'ucretsiz_ise_gizle', 100 );


add_action( 'woocommerce_before_add_to_cart_button', 'urun_detay_stok_kargo_durumu', 5 );
 
function urun_detay_stok_kargo_durumu() { ?>
	
<?php global $product; 
$kargo = $product->get_shipping_class();
$kargo_adi= get_term_by('slug',$kargo ,'product_shipping_class'); ?>
<?php if($kargo=="ucretsiz-kargo"):?>	
<span class="kargo-bedava"><img src="<?php echo get_template_directory_uri();?>/img/kargo-bedava.png"></span>
<?php endif;?>	

<?php if(get_field('ayni_gun_kargolanan_urun_mu_')):?>

<span class="ayni-gun-kargo"><img src="<?php echo get_template_directory_uri();?>/img/aynigunkargo.png"></span>

<?php endif;?>


<?php $stok_miktari = $product->get_stock_quantity();?>	
<?php if($stok_miktari>1):?>
<span class="stok-miktari"><?php echo $product->get_stock_quantity();?></span>
<?php endif;?>

<div class="clearfix margin-bottom-20"></div>
	
<?php }


add_filter( 'woocommerce_get_availability', 'stok_sorun', 1, 2);
function stok_sorun( $availability, $_product ) {
    

    if ( ! $_product->is_in_stock() ) { ?>
      <img src="<?php echo get_template_directory_uri();?>/img/stok-sorunuz.png" style="cursor: pointer;" data-toggle="modal" data-target="#stoksorunuz">	
				
<div class="modal fade" id="stoksorunuz" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ürün Haberdar Etme Formu</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php echo do_shortcode('[contact-form-7 id="393" title="Stok Formu"]');?>
      </div>
     
    </div>
  </div>
</div>
   <? }
    return $availability;
}




add_filter( 'woocommerce_output_related_products_args', 'jk_related_products_args', 20 );
  function jk_related_products_args( $args ) {
	$args['posts_per_page'] = 4; // 4 related products
	$args['columns'] = 4; // arranged in 2 columns
	return $args;
}




add_filter(  'gettext',  'change_related_products_title', 10, 3 );
add_filter(  'ngettext',  'change_related_products_title', 10, 3  );
function change_related_products_title( $translated, $text, $domain  ) {
     if( $text === 'Related products' && $domain === 'woocommerce' ){
         $translated = esc_html__( 'Benzer Ürünler', $domain );
     }
	
	 $translated = str_ireplace('Hoşunuza gidebilir&hellip;', 'Yanında iyi gider...', $translated);
	 $translated = str_ireplace('İlginizi çekebilir&hellip;', 'Gözünüzden kaçmasın...', $translated);
	
     return $translated;
}




add_filter( 'wc_order_statuses', 'wc_renaming_order_status' );
function wc_renaming_order_status( $order_statuses ) {
    foreach ( $order_statuses as $key => $status ) {
        if ( 'wc-completed' === $key ) 
            $order_statuses['wc-processing'] = _x( 'Sipariş Hazırlanıyor', 'Order status', 'woocommerce' );
    }
    return $order_statuses;
}




add_filter( 'woocommerce_register_shop_order_post_statuses', 'bbloomer_register_custom_order_status' );
 
function bbloomer_register_custom_order_status( $order_statuses ){
     
    // Status must start with "wc-"
    $order_statuses['wc-custom-status'] = array(                                            
    'label'                     => _x( 'Custom Status', 'Order status', 'woocommerce' ),
    'public'                    => false,                                            
    'exclude_from_search'       => false,                                            
    'show_in_admin_all_list'    => true,                                         
    'show_in_admin_status_list' => true,                                         
    'label_count'               => _n_noop( 'Custom Status <span class="count">(%s)</span>', 'Custom Status <span class="count">(%s)</span>', 'woocommerce' ),                                       
    );      
    return $order_statuses;
}
 
// ---------------------
// 2. Show Order Status in the Dropdown @ Single Order and "Bulk Actions" @ Orders
 
add_filter( 'wc_order_statuses', 'bbloomer_show_custom_order_status' );
 
function bbloomer_show_custom_order_status( $order_statuses ) {    
    $order_statuses['wc-custom-status'] = _x( 'Custom Status', 'Order status', 'woocommerce' );       
    return $order_statuses;
}
 
add_filter( 'bulk_actions-edit-shop_order', 'bbloomer_get_custom_order_status_bulk' );
 
function bbloomer_get_custom_order_status_bulk( $bulk_actions ) {
    // Note: "mark_" must be there instead of "wc"
    $bulk_actions['mark_custom-status'] = 'Change status to custom status';
    return $bulk_actions;
}
 
 
 
// ---------------------
// 3. Set Custom Order Status @ WooCommerce Checkout Process
 
add_action( 'woocommerce_thankyou', 'bbloomer_thankyou_change_order_status' );
 
function bbloomer_thankyou_change_order_status( $order_id ){
    if( ! $order_id ) return;
    $order = wc_get_order( $order_id );
 
    // Status without the "wc-" prefix
    $order->update_status( 'custom-status' );
}









add_filter( 'woocommerce_upsell_display_args', 'wc_change_number_related_products', 20 );

function wc_change_number_related_products( $args ) {
 
 $args['posts_per_page'] = 1;
 $args['columns'] = 4; //change number of upsells here
 return $args;
}





add_filter( 'woocommerce_get_catalog_ordering_args', 'ozel_siralama_argumanlar' );
function ozel_siralama_argumanlar( $args ) {
  $siralama_verisi = isset( $_GET['orderby'] ) ? wc_clean( $_GET['orderby'] ) : apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby' ) );
	if ( 'stok_durumuna_gore' == $siralama_verisi ) {
		$args['orderby'] = 'meta_value';
		$args['order'] = 'ASC';
		$args['meta_key'] = '_stock_status';
	}
	return $args;
}

add_filter( 'woocommerce_default_catalog_orderby_options', 'ozel_siralama_stok' );
add_filter( 'woocommerce_catalog_orderby', 'ozel_siralama_stok' );
function ozel_siralama_stok( $sirala ) {
	$sirala['stok_durumuna_gore'] = 'Stok Durumuna Göre';
	return $sirala;
}




add_action( 'wp_footer', 'bbloomer_cart_refresh_update_qty' ); 
 
function bbloomer_cart_refresh_update_qty() { 
   if (is_cart()) { 
      ?> 
      <script type="text/javascript"> 
         jQuery('div.woocommerce').on('click', 'input.qty', function(){ 
            jQuery("[name='update_cart']").trigger("click"); 
         }); 
      </script> 
      <?php 
   } 
}



add_filter( 'woocommerce_checkout_fields' , 'odeme_alan_ozellestirmeleri' );
function odeme_alan_ozellestirmeleri( $fields ) {
    unset($fields['billing']['billing_company']);
	unset($fields['billing']['billing_address_1']);
    unset($fields['billing']['billing_address_2']);
    unset($fields['billing']['billing_city']);
    unset($fields['billing']['billing_postcode']);
    unset($fields['billing']['billing_country']);
    unset($fields['billing']['billing_state']);
    unset($fields['order']['order_comments']);
    return $fields;
}



add_filter('woocommerce_enable_order_notes_field', '__return_false');




add_action('woocommerce_after_checkout_billing_form', 'tckimlikno');

function tckimlikno($checkout){
woocommerce_form_field('tckimlikno', array(
		'type' => 'text',
		'class' => array('my-field-class form-row-wide') ,
		'label' => __('Tc Kimlik Numaranız') ,
		'placeholder' => __('Tc Kimlik Numaranız') ,
		'required' => "true"
		) ,

$checkout->get_value('tckimlikno'));
}

add_action('woocommerce_checkout_process', 'ozel_alan_uyari');

function ozel_alan_uyari() {

if (!$_POST['tckimlikno']) wc_add_notice(__('Lütfen 11 Haneli TC Kimlik Numaranızı Yazınız') , 'error');

}

add_action( 'woocommerce_checkout_update_order_meta', 'ozel_alan_sipariste_guncelleme' );
 
function ozel_alan_sipariste_guncelleme( $order_id ) {   
if ( $_POST['tckimlikno'] ) update_post_meta( $order_id, '_tckimlikno', sanitize_text_field($_POST['tckimlikno']) );
}
 
add_action( 'woocommerce_admin_order_data_after_billing_address', 'ozel_alan_sipariste_gosterme', 10, 1 );

function ozel_alan_sipariste_gosterme( $order ) {    
echo '<p><strong>'.__('Müşteri TC Kimlik Numarası').':</strong> ' . get_post_meta( $order->id, '_tckimlikno', true ) . '</p>';
}

add_action( 'woocommerce_order_status_kargolandi', 'kargolandi_emaili', 20, 2 );
  
function kargolandi_emaili( $order_id, $order ) {
      
    $heading = 'Siparişiniz Kargolandı';
    $subject = 'Siparişiniz Kargolandı';
    $mailer = WC()->mailer()->get_emails();
    $mailer['WC_Email_Customer_Completed_Order']->heading = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->settings['heading'] = $heading;
    $mailer['WC_Email_Customer_Completed_Order']->subject = $subject;
    $mailer['WC_Email_Customer_Completed_Order']->settings['subject'] = $subject;
    $mailer['WC_Email_Customer_Completed_Order']->trigger( $order_id );
      
}



add_action( 'admin_init', 'kullanicidan_alan_gizleme' );
function kullanicidan_alan_gizleme() {
global $user_ID;

$user_id = get_current_user_id();
if ($user_id == 2 ) {
	remove_menu_page( 'edit.php?post_type=acf-field-group' );
	remove_menu_page( 'tools.php' );
	remove_menu_page( 'index.php' );
	remove_menu_page( 'edit-comments.php' );
	remove_menu_page( 'upload.php' );
	remove_menu_page( 'admin.php?page=wpcf7' );
	remove_menu_page( 'users.php' );
	remove_menu_page( 'itsec' );
	remove_menu_page( 'options-general.php' );
	remove_menu_page( 'plugins.php' );
	//remove_menu_page( 'themes.php' );



add_action('admin_head', 'kullanicidan_alan_gizleme_2');
function kullanicidan_alan_gizleme_2() {
  echo '<style>
  

#toplevel_page_wpcf7, .subsubsub, #toplevel_page_smush ,#toplevel_page_wphb, #toplevel_page_wp-defender, #toplevel_page_wpseo_dashboard
 
{ display: none;}
.hide-if-no-customize {display:none;}
#menu-appearance .hide-if-no-customize {display:none;}
#menu-appearance .wp-first-item {display:none;}
  </style>';
}
	
}
	


	
}





