<?php $slider_arkaplan_rengi = get_field('slider_arka_plan_rengi','option');?>
<style>
.slider-arkasi {background-color:<?php the_field('slider_arka_plan_rengi','option');?> }
	
</style>	