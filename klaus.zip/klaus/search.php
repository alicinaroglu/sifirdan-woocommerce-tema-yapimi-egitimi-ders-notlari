<?php get_header(); ?>
<div class="row haber-detay">

<div class="col-md-8">
	
	<h2 class="baslik-1"><?php printf( __( '%s'), get_search_query() ); ?> için arama sonuçları</h2>
	
<?php if ( have_posts() ) : ?>
<?php 
	
$sayi=1;
while ( have_posts() ) : the_post(); ?>

<?php if ($sayi==1):?>		
	
<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumb-large');?></a>
<a href="<?php the_permalink(); ?>"><h1 class="haber-ic-baslik kategori-manset"><?php the_title(); ?></h1> </a>

	
<?php else : ?>
	
	
<div class="row">

	<div class="col-md-6">
	
		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumb-populer-oge');?></a>

	
	</div>
	
	<div class="col-md-6">
	
	<a href="<?php the_permalink(); ?>"><h1 class="kategori-haber-baslik"><?php the_title(); ?></h1> </a>
	<div class="kategori-haber-aciklama"><a href="<?php the_permalink(); ?>"><?php the_excerpt();?></a></div>	
		
	</div>
	
</div>	
	
	
	
	
	<?php endif; ?>
		
<?php $sayi++; endwhile; ?>

<?php else : ?>
Aradığınız kelime ile sonuç bulunamadı
<?php endif; ?>
	</div>
<div class="col-md-4">
<?php the_field('kategori_sag_blok_reklam_alani','option');?>	
<div class="clearfix"></div>	
	
<h2 class="baslik-1">Son Haberler</h2>
<?php
query_posts('orderby=date&order=DESC&posts_per_page=6');
if (have_posts()) : while (have_posts()) : the_post();
?>
    
<div class="son-haberler-oge">	
<a href="<?php the_permalink();?>">

<div class="son-haberler-tarih"><?php the_time( 'H:i' ); ?></div>
	
<div class="son-haberler-oge-baslik"><?php the_title();?>	</div>
		
</a>		
</div>	
<?php
endwhile; endif;
wp_reset_query();
?>	
	
</div>

</div>
<?php get_footer(); ?>