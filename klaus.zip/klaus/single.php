<?php get_header(); ?>
<?php while ( have_posts() ) : the_post(); ?>
<div class="container-fluid">
	<div class="row">
	<div class="col-md-4 sayfa-ic-sol">
		<?php $solfoto1=get_field('sol_fotograf_1',98);?>
		<img src="<?php echo $solfoto1['url'];?>" class="solfoto1">
		<div class="clearfix"></div>
	</div>
	<div class="col-md-1"></div>	
	<div class="col-md-7 sayfa-ic-sag">
	<div class="clearfix margin-bottom-40 "></div>	
	<h1 class="anasayfa-buyuk-baslik" align="left"><span class="bold renk-gri"><?php the_title();?></span></h1>	
	<?php the_post_thumbnail();?>
	<div class="clearfix margin-top-20"></div>	
	<?php the_content();?>
	</div>
	<div class="clearfix"></div>	
	</div>
</div>
<?php endwhile; ?>
<div class="clearfix"></div>
<?php get_footer(); ?>