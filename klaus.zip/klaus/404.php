<?php get_header(); ?>

<div class="container">
<h1>SAYFA BULUNAMADI</h1>
SAYFA BULUNAMADI
</div>

<?php get_footer(); ?>