<?php get_header(); ?>
<?php
$sayfa_arkaplan = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumb-slider' );
?>
<div class="sayfa-ust container-fluid" style="background-image: url(<?php echo $sayfa_arkaplan[0]; ?> ) !important; background-size: cover;">
<div class="container">
<div class="row">
  <div class="col-md-12">
  <h1 class="renk-beyaz bold text-left f30"><?php the_field('bizden_haberler_2başlık', 'option'); ?></h1>
    
  <div class="breadcrumbs margin-bottom-10" xmlns:v="http://rdf.data-vocabulary.org/#">
    <?php if(function_exists('bcn_display'))
    {
        bcn_display();
    }?>
  </div>
    
  </div>
</div>
</div>

</div>

<div class="container-fluid margin-top-30">
<div class="container">
<div class="row">

<?php while ( have_posts() ) : the_post(); ?>
<div class="col-md-4">
<?php if ( has_post_thumbnail() ) { ?>
<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumb-large',array('class'=>'img-fluid')); ?></a>
<?php } else { ?>
<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumb-large',array('class'=>'img-fluid')); ?></a><?php }?>
<h3 class="baslik-rengi bold"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
<?php the_excerpt(); ?>
</div>
<?php endwhile; ?>
<div class="clearfix"></div>
<div class="container margin-top-20"><?php if(function_exists('wp_paginate')) { wp_paginate();} ?> </div>


</div>
</div>
</div>
<?php get_footer(); ?>